xlsx-reader
===========

Python3 library optimised for reading very large Excel XLSX files, including those with hundreds of columns as well as rows.


# License

This is free and unencumbered software released into the public domain. See UNLICENSE.md for details.